import { createApp } from 'vue'
import App from './App.vue'

// Pinia
import { createPinia } from 'pinia'

// Router
import router from './router'

// Vuetify (default export)
import vuetify from './plugins/vuetify'

// اختياري: إن لم يكن لديك هذا الملف، احذفي هذا السطر أو أنشئيه لاحقًا
// import './assets/main.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)
app.use(vuetify)

app.mount('#app')