// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/login.vue'

// Admin views
import AdminLayout from '../assets/Layout/AdminLayout.vue'
import Dashboard from '../views/admin/Dashboard.vue'
import Employees from '../views/admin/Employee.vue'
import Complaints from '../views/admin/Complaints.vue'
import Reports from '../views/admin/Reports.vue'

// Employee views
import EmployeeLayout from '../assets/Layout/EmployeeLayout.vue'
import EmployeeComplaints from '../views/employee/Complaints.vue'
import ComplaintDetails from '../views/employee/ComplaintDetails.vue'

const routes = [
  { path: '/', component: Login },

  {
    path: '/admin',
    component: AdminLayout,
    children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'employees', component: Employees },
      { path: 'complaints', component: Complaints },
      { path: 'reports', component: Reports }
    ]
  },

  {
    path: '/employee',
    component: EmployeeLayout,
    children: [
      { path: 'complaints', component: EmployeeComplaints },
      { path: 'complaints/:id', component: ComplaintDetails }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router