// src/stores/employees.js
import { defineStore } from 'pinia'
import axios from 'axios'

export const useEmployeesStore = defineStore('employees', {
  state: () => ({
    employees: [
      { id: 1, name: 'John Doe', number: '1001', department: 'Water Dept', password: '123456' },
      { id: 2, name: 'Jane Smith', number: '1002', department: 'Electricity Dept', password: 'abcdef' }
    ]
  }),
  actions: {
    async fetchEmployees() {
      // لاحقًا: استبدلي هذا بـ API call من Laravel
      // const res = await axios.get('/api/employees')
      // this.employees = res.data
    },
    async addEmployee(employee) {
      this.employees.push(employee)
      // لاحقًا: await axios.post('/api/employees', employee)
    },
    async deleteEmployee(id) {
      this.employees = this.employees.filter(e => e.id !== id)
      // لاحقًا: await axios.delete(`/api/employees/${id}`)
    },
    async updateEmployee(id, updated) {
      const index = this.employees.findIndex(e => e.id === id)
      if (index !== -1) {
        this.employees[index] = { ...updated }
      }
      // لاحقًا: await axios.put(`/api/employees/${id}`, updated)
    }
  }
})