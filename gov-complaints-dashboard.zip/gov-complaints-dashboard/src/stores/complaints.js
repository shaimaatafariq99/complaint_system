import { defineStore } from 'pinia'
import axios from 'axios'

export const useComplaintsStore = defineStore('complaints', {
  state: () => ({
    complaints: [
      { id: 101, description: 'Water supply issue', status: 'New' },
      { id: 102, description: 'Electricity outage', status: 'In Progress' }
    ]
  }),
  actions: {
    async fetchComplaints() {
      // Later: replace with API call
      // const res = await axios.get('/api/complaints')
      // this.complaints = res.data
    },
    async updateComplaint(id, data) {
      const index = this.complaints.findIndex(c => c.id === id)
      if (index !== -1) {
        this.complaints[index] = { ...this.complaints[index], ...data }
      }
      // Later: await axios.put(`/api/complaints/${id}`, data)
    },
    async deleteComplaint(id) {
      this.complaints = this.complaints.filter(c => c.id !== id)
      // Later: await axios.delete(`/api/complaints/${id}`)
    }
  }
})