// src/stores/auth.js
import { defineStore } from 'pinia'
import axios from 'axios'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    token: null,
  }),
  actions: {
    async login(credentials) {
      // Placeholder until API is ready
      this.user = {
        id: 1,
        name: credentials.email,
        role: credentials.role // 👈 الدور يأتي من واجهة تسجيل الدخول
      }
      this.token = 'fake-jwt-token'
      axios.defaults.headers.common['Authorization'] = `Bearer ${this.token}`
    },
    logout() {
      this.user = null
      this.token = null
      delete axios.defaults.headers.common['Authorization']
    }
  }
})