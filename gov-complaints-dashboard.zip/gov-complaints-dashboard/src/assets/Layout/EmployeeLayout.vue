<!-- src/layouts/EmployeeLayout.vue -->
<template>
  <v-app>
    <v-navigation-drawer app permanent>
      <img src="../assets/logo.png" alt="Logo" class="mb-4" style="width: 80%; display: block; margin: 0 auto;">
      <v-list>
        <v-list-item-title class="text-h6">Employee Panel</v-list-item-title>
        <v-divider></v-divider>
        <v-list-item link to="/employee/complaints">
          <v-list-item-title>Complaints</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app color="#0A3A86" dark>
      <v-toolbar-title>Employee Dashboard</v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn @click="logout" color="white" icon="mdi-logout"></v-btn>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script setup>
import { useAuthStore } from '../../stores/auth'
const store = useAuthStore()

function logout() {
  store.logout()
  window.location.href = '/'
}
</script>