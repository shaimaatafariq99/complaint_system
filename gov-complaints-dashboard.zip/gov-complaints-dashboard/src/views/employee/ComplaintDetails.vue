<!-- src/views/employee/ComplaintDetails.vue -->
<template>
  <v-container>
    <v-card>
      <v-card-title>Complaint Details</v-card-title>
      <v-card-text>
        <p><strong>ID:</strong> {{ complaint.id }}</p>
        <p><strong>Description:</strong> {{ complaint.description }}</p>
        <p><strong>Status:</strong> {{ complaint.status }}</p>
        <v-btn color="#0A3A86" @click="updateStatus('In Progress')">Mark In Progress</v-btn>
        <v-btn color="success" @click="updateStatus('Resolved')">Mark Resolved</v-btn>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const complaint = ref({
  id: 201,
  description: 'Road damage',
  status: 'New'
})

function updateStatus(status) {
  complaint.value.status = status
  alert(`Complaint status updated to ${status}`)
}
</script>