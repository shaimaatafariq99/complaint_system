<!-- src/views/employee/Complaints.vue -->
<template>
  <v-container>
    <v-card>
      <v-card-title>Complaints</v-card-title>
      <v-data-table :items="complaints" :headers="headers">
        <template v-slot:item.actions="{ item }">
          <v-btn color="info" @click="openComplaintDialog(item)">Follow</v-btn>
        </template>
      </v-data-table>
    </v-card>

    <!-- Complaint Details Dialog -->
    <v-dialog v-model="dialog" max-width="600">
      <v-card>
        <v-card-title>Complaint Details</v-card-title>
        <v-card-text v-if="selectedComplaint">
          <p><strong>ID:</strong> {{ selectedComplaint.id }}</p>
          <p><strong>Description:</strong> {{ selectedComplaint.description }}</p>
          <p><strong>Status:</strong> {{ selectedComplaint.status }}</p>

          <v-textarea v-model="note" label="Add Note / Request Info"></v-textarea>
          <v-btn color="#0A3A86" class="mt-2" @click="addNote">Submit Note</v-btn>

          <v-divider class="my-3"></v-divider>
          <h3>History</h3>
          <v-timeline>
            <v-timeline-item
              v-for="(log, index) in selectedComplaint.logs"
              :key="index"
              :dot-color="log.color"
            >
              <strong>{{ log.date }}</strong> - {{ log.action }} (by {{ log.user }})
            </v-timeline-item>
          </v-timeline>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const complaints = ref([
  {
    id: 201,
    description: 'Road damage',
    status: 'New',
    logs: [
      { date: '2025-12-01', action: 'Complaint submitted', user: 'Citizen', color: 'blue' }
    ]
  }
])

const headers = [
  { text: 'ID', value: 'id' },
  { text: 'Description', value: 'description' },
  { text: 'Status', value: 'status' },
  { text: 'Actions', value: 'actions', sortable: false }
]

const dialog = ref(false)
const selectedComplaint = ref(null)
const note = ref('')

function openComplaintDialog(item) {
  selectedComplaint.value = { ...item }
  dialog.value = true
}

function addNote() {
  selectedComplaint.value.logs.push({
    date: new Date().toISOString().split('T')[0],
    action: `Note added: ${note.value}`,
    user: 'Employee',
    color: 'purple'
  })
  note.value = ''
}
</script>