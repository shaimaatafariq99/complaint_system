<template>
  <v-container class="d-flex justify-center align-center" style="height:100vh;">
    <v-card width="400">
      <img src="../assets/logo.png" alt="Logo" class="mb-4" style="width: 100px; display: block; margin: 0 auto;">
      <v-card-title class="text-center">Login</v-card-title>
      <v-card-text>
        <v-form @submit.prevent="login">
          <v-text-field v-model="number" label="Phone Number" required></v-text-field>
          <v-text-field v-model="password" label="Password" type="password" required></v-text-field>

          <!-- اختيار الدور -->
          <v-select
            v-model="role"
            :items="roles"
            label="Select Role"
            required
          ></v-select>

          <v-btn type="submit" color="#0A3A86" block>Login</v-btn>
        </v-form>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'
import { useAuthStore } from '../stores/auth'

const store = useAuthStore()
const number = ref('')
const password = ref('')
const role = ref(null)
const roles = ['admin', 'employee']

async function login() {
  await store.login({ number: number.value, password: password.value, role: role.value })

  if (store.user.role === 'admin') {
    window.location.href = '/admin/dashboard'
  } else if (store.user.role === 'employee') {
    window.location.href = '/employee/complaints'
  }
}
</script>