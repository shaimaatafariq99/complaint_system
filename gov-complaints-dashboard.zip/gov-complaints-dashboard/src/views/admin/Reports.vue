<!-- src/views/admin/Reports.vue -->
<template>
  <v-container>
    <v-card>
      <v-card-title>Reports</v-card-title>
      <v-card-text>
        <v-btn color="#0A3A86" class="mb-3" @click="generateReport('csv')">Export CSV</v-btn>
        <v-btn color="secondary" class="mb-3" @click="generateReport('pdf')">Export PDF</v-btn>
        <v-divider></v-divider>
        <p>Reports will include statistics about complaints, employees, and system performance.</p>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script setup>
function generateReport(type) {
  alert(`Generating ${type.toUpperCase()} report...`)
}
</script>