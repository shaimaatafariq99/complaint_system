<!-- src/views/admin/Dashboard.vue -->
<template>
  <v-container>
    <v-card>
      <v-card-title>Admin Dashboard</v-card-title>
      <v-card-text>
        <p>Overview of system statistics, complaints, and reports.</p>
      </v-card-text>
    </v-card>
  </v-container>
</template>