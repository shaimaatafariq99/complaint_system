<template>
  <v-container>
    <v-card>
      <v-card-title>Employees Management</v-card-title>
      <v-data-table :items="employees" :headers="headers">
        <template v-slot:item.actions="{ item }">
          <v-btn color="info" @click="openViewDialog(item)">View</v-btn>
          <v-btn color="warning" @click="openEditDialog(item)">Edit</v-btn>
          <v-btn color="error" @click="deleteEmployee(item.id)">Delete</v-btn>
        </template>
      </v-data-table>
      <v-btn color="primary" class="mt-3" @click="openAddDialog">Add Employee</v-btn>
    </v-card>

    <!-- Add Employee Dialog -->
    <v-dialog v-model="addDialog" max-width="500">
      <v-card>
        <v-card-title>Add Employee</v-card-title>
        <v-card-text>
          <v-form @submit.prevent="addEmployee">
            <v-text-field v-model="newEmployee.name" label="Name" required></v-text-field>
            <v-text-field v-model="newEmployee.number" label="User Number" required></v-text-field>
            <v-text-field v-model="newEmployee.department" label="Department" required></v-text-field>
            <v-text-field
              v-model="newEmployee.password"
              :type="showPassword ? 'text' : 'password'"
              label="Password"
              required
              append-inner-icon="mdi-eye"
              @click:append="showPassword = !showPassword"
            ></v-text-field>
            <v-btn type="submit" color="#0A3A86">Save</v-btn>
          </v-form>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- View Employee Dialog -->
    <v-dialog v-model="viewDialog" max-width="400">
      <v-card>
        <v-card-title>Employee Details</v-card-title>
        <v-card-text v-if="selectedEmployee">
          <p><strong>ID:</strong> {{ selectedEmployee.id }}</p>
          <p><strong>Name:</strong> {{ selectedEmployee.name }}</p>
          <p><strong>User Number:</strong> {{ selectedEmployee.number }}</p>
          <p><strong>Department:</strong> {{ selectedEmployee.department }}</p>
          <v-text-field
            v-model="selectedEmployee.password"
            :type="showPassword ? 'text' : 'password'"
            label="Password"
            readonly
            append-inner-icon="mdi-eye"
            @click:append="showPassword = !showPassword"
          ></v-text-field>
        </v-card-text>
      </v-card>
    </v-dialog>

    <!-- Edit Employee Dialog -->
    <v-dialog v-model="editDialog" max-width="500">
      <v-card>
        <v-card-title>Edit Employee</v-card-title>
        <v-card-text v-if="selectedEmployee">
          <v-form @submit.prevent="saveEmployee">
            <v-text-field v-model="selectedEmployee.name" label="Name" required></v-text-field>
            <v-text-field v-model="selectedEmployee.number" label="User Number" required></v-text-field>
            <v-text-field v-model="selectedEmployee.department" label="Department" required></v-text-field>
            <v-text-field
              v-model="selectedEmployee.password"
              :type="showPassword ? 'text' : 'password'"
              label="Password"
              required
              append-inner-icon="mdi-eye"
              @click:append="showPassword = !showPassword"
            ></v-text-field>
            <v-btn type="submit" color="#0A3A86">Save</v-btn>
          </v-form>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'
import { useEmployeesStore } from '../../stores/employee'

const store = useEmployeesStore()
const employees = store.employees

const headers = [
  { text: 'ID', value: 'id' },
  { text: 'Name', value: 'name' },
  { text: 'User Number', value: 'number' },
  { text: 'Department', value: 'department' },
  { text: 'Actions', value: 'actions', sortable: false }
]

const addDialog = ref(false)
const viewDialog = ref(false)
const editDialog = ref(false)
const selectedEmployee = ref(null)

const newEmployee = ref({
  name: '',
  number: '',
  department: '',
  password: ''
})

const showPassword = ref(false)

function openAddDialog() {
  addDialog.value = true
}

function addEmployee() {
  store.addEmployee({ id: Date.now(), ...newEmployee.value })
  addDialog.value = false
  newEmployee.value = { name: '', number: '', department: '', password: '' }
}

function openViewDialog(item) {
  selectedEmployee.value = { ...item }
  viewDialog.value = true
}

function openEditDialog(item) {
  selectedEmployee.value = { ...item }
  editDialog.value = true
}

function saveEmployee() {
  store.updateEmployee(selectedEmployee.value.id, selectedEmployee.value)
  editDialog.value = false
}

function deleteEmployee(id) {
  store.deleteEmployee(id)
}
</script>