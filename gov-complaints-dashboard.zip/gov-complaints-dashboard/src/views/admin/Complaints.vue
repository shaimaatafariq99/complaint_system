<!-- src/views/admin/Complaints.vue -->
<template>
  <v-container>
    <v-card>
      <v-card-title>Complaints Management</v-card-title>
      <v-data-table :items="complaints" :headers="headers">
        <template v-slot:item.actions="{ item }">
          <v-btn color="info" @click="openComplaintDialog(item)">View / Edit</v-btn>
        </template>
      </v-data-table>
    </v-card>

    <!-- Complaint Details Dialog -->
    <v-dialog v-model="dialog" max-width="600">
      <v-card>
        <v-card-title>Complaint Details</v-card-title>
        <v-card-text v-if="selectedComplaint">
          <v-form @submit.prevent="saveComplaint">
            <v-text-field v-model="selectedComplaint.description" label="Description"></v-text-field>
            <v-select v-model="selectedComplaint.status" :items="statuses" label="Status"></v-select>
            <v-btn type="submit" color="#0A3A86">Save</v-btn>
          </v-form>

          <v-divider class="my-3"></v-divider>
          <h3>History</h3>
          <v-timeline>
            <v-timeline-item
              v-for="(log, index) in selectedComplaint.logs"
              :key="index"
              :dot-color="log.color"
            >
              <strong>{{ log.date }}</strong> - {{ log.action }} (by {{ log.user }})
            </v-timeline-item>
          </v-timeline>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script setup>
import { ref } from 'vue'

const complaints = ref([
  {
    id: 101,
    description: 'Water supply issue',
    status: 'New',
    logs: [
      { date: '2025-12-01', action: 'Complaint submitted', user: 'Citizen', color: 'blue' },
      { date: '2025-12-02', action: 'Marked In Progress', user: 'Admin', color: 'orange' }
    ]
  },
  {
    id: 102,
    description: 'Electricity outage',
    status: 'In Progress',
    logs: [
      { date: '2025-12-03', action: 'Complaint submitted', user: 'Citizen', color: 'blue' }
    ]
  }
])

const headers = [
  { text: 'ID', value: 'id' },
  { text: 'Description', value: 'description' },
  { text: 'Status', value: 'status' },
  { text: 'Actions', value: 'actions', sortable: false }
]

const dialog = ref(false)
const selectedComplaint = ref(null)
const statuses = ['New', 'In Progress', 'Resolved', 'Rejected']

function openComplaintDialog(item) {
  selectedComplaint.value = { ...item }
  dialog.value = true
}

function saveComplaint() {
  selectedComplaint.value.logs.push({
    date: new Date().toISOString().split('T')[0],
    action: `Status changed to ${selectedComplaint.value.status}`,
    user: 'Admin',
    color: 'green'
  })
  dialog.value = false
}
</script>